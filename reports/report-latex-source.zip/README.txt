Compile main.tex with pdfLaTeX twice (TeX Live/MacTeX or Overleaf).
Command: pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -jobname=report main.tex

10 pages. 27 pipeline tests. 36 unique declared report values. Annex: 321.66 CAD.
Submission checker has 6 items and reuses report/security checks without rerunning pytest.
